# test
comandos estudiados
git init
git clone
git status
